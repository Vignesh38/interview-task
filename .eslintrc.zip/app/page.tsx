import HomePage from "./components/pages/homepage";
// import Nav from "./components/pages/Header";
// import navbars from "./components/organisms/Navbar";

// import { fadeInUp, SlideUp } from "./atoms/animation/animation"

export default function Home() {
  return (
    <div>
    
    <HomePage />
    </div>
  );
}
