import Menu from "../organisms/Navbar";

// import { fadeInUp, SlideUp } from "./atoms/animation/animation"

export default function Nav() {
  return (
    <Menu />   

    
  );
}
